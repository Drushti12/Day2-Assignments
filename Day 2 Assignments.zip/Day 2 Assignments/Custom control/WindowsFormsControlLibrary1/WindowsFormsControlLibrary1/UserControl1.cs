﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsControlLibrary1
{
    public partial class UserControl1: UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            String[] currency = { "€ (Euro)", "£ (Ponds)", "$ (US Doller)", "¥ (Japanese yen)",
                                "CHF (Switzerland)","£ (United Kingdom)","kr (Norway)",
                                 "₺ (Turkey)","₪ (Israel)","₦ (Nigeria)"};
            // euro, pounds,us doller,japnees yen, indian rupee
            comboBox1.Items.Add("₹ (Indian rupees)");
            foreach (String cu in currency)
            {
                comboBox2.Items.Add(cu);
            }
        }

        private void CONVERT_Click(object sender, EventArgs e)
        {
            String currency2 = Convert.ToString(comboBox2.SelectedItem);
            double amount = Convert.ToDouble(textBox1.Text);
            double value1;
            switch (currency2)
            {
                case "€ (Euro)":
                    value1 = 0.011;
                    break;
                case "£ (Ponds)":
                    value1 = 0.010;
                    break;
                case "$ (US Doller)":
                    value1 = 0.014;
                    break;
                case "¥ (Japanese yen)":
                    value1 = 1.41;
                    break;
                case "CHF (Switzerland)":
                    value1 = 0.012;
                    break;
                case "£ (United Kingdom)":
                    value1 = 0.010;
                    break;
                case "kr (Norway)":
                    value1 = 0.12;
                    break;
                case "₺ (Turkey)":
                    value1 = 0.11;
                    break;
                case "₪ (Israel)":
                    value1 = 0.044;
                    break;
                case "₦ (Nigeria)":
                    value1 = 5.12;
                    break;
                default:
                    value1 = 0;
                    MessageBox.Show("please enter valid choice...");
                    break;
            }
            double convertedamount = value1 * amount;
            label4.Text = convertedamount.ToString();
        }
    }
}
