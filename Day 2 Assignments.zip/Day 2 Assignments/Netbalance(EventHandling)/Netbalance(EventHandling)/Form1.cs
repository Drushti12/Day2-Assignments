﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Netbalance_EventHandling_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            EventHandling eh = new EventHandling();
            eh.netBalance = Convert.ToInt32(textBox1.Text);

            if (eh.netBalance >= 100000)
            {
                eh.overBalance(eh.netBalance);
            }
            else if (eh.netBalance <= 5000)
            {
                eh.underBalance();
            }
            else
            {
                MessageBox.Show("No Tax to be paid on ur Total Amount");
            }
        }
    }
}
