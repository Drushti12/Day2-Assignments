﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Netbalance_EventHandling_
{
    class EventHandling
    {
        int netbalance;

        public int netBalance
        {
            get
            {
                return netbalance;
            }

            set
            {
                netbalance = value;
            }
        }

        public void overBalance(int netbal)
        {
            double tax = netbal * 0.18;
            MessageBox.Show("Tax on your NetBalance is "+ tax);
        }
        public void underBalance()
        {
            MessageBox.Show("Maintain Minimum Balance up to 5000/-");
        }
    }
}
